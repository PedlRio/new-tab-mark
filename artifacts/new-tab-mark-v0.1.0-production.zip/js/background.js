(function(){browser.runtime.onMessage.addListener((function(o,e,n){console.log("Hello from the background")}))})();
//# sourceMappingURL=background.js.map